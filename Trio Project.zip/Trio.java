package Week2;

import java.util.Arrays;
import java.util.Objects;

public class Trio<T> {
    private T item1;
    private T item2;
    private T item3;

    // constructors
    public Trio(T item1, T item2, T item3){
        this.item1 = item1;
        this.item2 = item2;
        this.item3 = item3;
    }
    public Trio(T item1){
        this.item1 = item1;
    }

    // getter & setter
    public T getItem1() {
        return item1;
    }
    public T getItem2() {
        return item2;
    }
    public T getItem3() {
        return item3;
    }
    public void setItem1(T item1) {
        this.item1 = item1;
    }
    public void setItem2(T item2) {
        this.item2 = item2;
    }
    public void setItem3(T item3) {
        this.item3 = item3;
    }

    // methods

    @Override
    public String toString() {
        return "Trio{" +
                "item1=" + item1 +
                ", item2=" + item2 +
                ", item3=" + item3 +
                '}';
    }

    public void replaceAll(T item){
        item1 = item;
        item2 = item;
        item3 = item;
    }

    public boolean hasDuplicates(){
        if (item1.equals(item2) || item1.equals(item3) || item2.equals(item3)){
            return true;
        }
        return false;
    }

    public int count(T trio){
        int number = 0;
        Object[] array= {getItem1(), getItem2(), getItem3()};
        for (Object item : array){
            if (trio.equals(item)){
                number++;
            }
        }
        return number;
    }

    @Override
    public boolean equals(Object o){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Trio<?> trio = (Trio<?>) o;

        Object[] arr1 = {getItem1(), getItem2(), getItem3()};
        Object[] arr2 = {trio.getItem1(),trio.getItem2(), trio.getItem3()};

        Arrays.sort(arr1);
        Arrays.sort(arr2);

        return Objects.equals(arr1[0], arr2[0]) &&
                Objects.equals(arr1[1], arr2[1]) &&
                Objects.equals(arr1[2], arr2[2]);
    }
}
